import type { Metadata } from 'next'
import { Inter, DM_Sans } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const dmSans = DM_Sans({ subsets: ["latin"], variable: "--font-dm-sans", weight: ["400", "500", "600", "700"] });

export const metadata: Metadata = {
  title: 'UniDeals - Save Big on Your Education Journey | Best Scholarship Platform India',
  description: 'India\'s #1 scholarship and coupon platform for students. Discover exclusive deals on university degrees, skilling courses, and more. Find scholarships, education discounts, online course coupons, university fee waivers, and student deals.',
  keywords: ['scholarships India', 'student discounts', 'education coupons', 'university scholarships', 'online course discounts', 'MBA scholarships', 'BCA scholarships', 'Coursera discount', 'Udemy coupons', 'upGrad offers', 'student deals', 'education deals India', 'college scholarships', 'learning platform discounts', 'skill development courses', 'ChatGPT education', 'AI learning discounts', 'Gemini courses', 'Claude AI learning'],
  generator: 'v0.app',
  robots: 'index, follow',
  openGraph: {
    title: 'UniDeals - Save Big on Your Education Journey',
    description: 'India\'s #1 scholarship and coupon platform for students. Discover exclusive deals on university degrees, skilling courses, and more.',
    type: 'website',
    locale: 'en_IN',
    siteName: 'UniDeals',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'UniDeals - Save Big on Your Education Journey',
    description: 'India\'s #1 scholarship and coupon platform for students.',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} ${dmSans.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
