"use client";

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import {
  Flame,
  ChevronLeft,
  ChevronRight,
  BadgeCheck,
  Clock,
  MousePointerClick,
  Users,
  Eye,
  Gift,
  CheckCircle2,
  Sparkles,
  Star,
  Copy,
  Check,
  LogOut,
  Plus,
  Pencil,
  Trash2,
  Download,
  BarChart3,
  Database,
  Settings,
  Award,
  TrendingUp,
  ShieldCheck,
  FileEdit,
  Save,
  ImageIcon,
  AlignLeft,
  Bold,
  Italic,
  List,
  Heading2,
  ExternalLink,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Footer, Header, BlogPost, initialBlogPosts } from "@/components/shared";

// Types
interface Coupon {
  id: number;
  brand: string;
  title: string;
  desc: string;
  initials: string;
  colorClass: string;
  tags: string[];
  cat: string;
  success: number;
  clicks: number;
  conv: number;
  expiry: string;
  code: string;
  verified: boolean;
  live: boolean;
  image?: string;
  isPopular?: boolean;
  order?: number;
  discount?: string;
  discountValue?: string;
}

interface Lead {
  id: number;
  name: string;
  email: string;
  phone: string;
  couponId: number;
  couponBrand: string;
  timestamp: string;
}

// Initial Data
const initialCoupons: Coupon[] = [
  {
    id: 1,
    brand: "Amity Online",
    title: "20% Off on MBA Program",
    desc: "Get flat 20% discount on MBA program enrollment fees",
    initials: "AO",
    colorClass: "from-blue-500 to-blue-700",
    tags: ["MBA", "Online"],
    cat: "University Degrees",
    success: 92,
    clicks: 2453,
    conv: 847,
    expiry: "2026-04-20",
    code: "AMITY20MBA",
    verified: true,
    live: true,
    discount: "UP TO",
    discountValue: "20%",
  },
  {
    id: 2,
    brand: "Coursera",
    title: "Free Certificate on First Course",
    desc: "Complete your first course and get certificate free",
    initials: "CO",
    colorClass: "from-indigo-500 to-purple-600",
    tags: ["Certificate", "Skills"],
    cat: "Skilling Courses",
    success: 88,
    clicks: 3421,
    conv: 1205,
    expiry: "2026-04-25",
    code: "COURSERA1FREE",
    verified: true,
    live: true,
    discount: "GET",
    discountValue: "FREE",
  },
  {
    id: 3,
    brand: "Manipal University",
    title: "₹15,000 Scholarship",
    desc: "Apply for BCA/MCA and get instant scholarship",
    initials: "MU",
    colorClass: "from-orange-500 to-red-600",
    tags: ["BCA", "MCA", "Scholarship"],
    cat: "University Degrees",
    success: 95,
    clicks: 1876,
    conv: 623,
    expiry: "2026-04-18",
    code: "MANIPAL15K",
    verified: true,
    live: true,
    discount: "SAVE",
    discountValue: "₹15K",
  },
  {
    id: 4,
    brand: "Udemy",
    title: "90% Off All Courses",
    desc: "Massive discount on entire course catalog",
    initials: "UD",
    colorClass: "from-purple-500 to-pink-600",
    tags: ["All Courses", "Limited"],
    cat: "Skilling Courses",
    success: 97,
    clicks: 5632,
    conv: 2341,
    expiry: "2026-04-15",
    code: "UDEMY90OFF",
    verified: true,
    live: true,
    discount: "UP TO",
    discountValue: "90%",
  },
  {
    id: 5,
    brand: "NMIMS Global",
    title: "Free Application Fee",
    desc: "Waive off application fee for all programs",
    initials: "NG",
    colorClass: "from-teal-500 to-cyan-600",
    tags: ["Application", "Free"],
    cat: "University Degrees",
    success: 89,
    clicks: 1234,
    conv: 456,
    expiry: "2026-04-30",
    code: "NMIMSFREE",
    verified: true,
    live: false,
    discount: "GET",
    discountValue: "FREE",
  },
  {
    id: 6,
    brand: "upGrad",
    title: "₹25,000 Off on Data Science",
    desc: "Special discount on Data Science certification",
    initials: "UG",
    colorClass: "from-green-500 to-emerald-600",
    tags: ["Data Science", "Tech"],
    cat: "Skilling Courses",
    success: 91,
    clicks: 2876,
    conv: 934,
    expiry: "2026-04-22",
    code: "UPGRAD25K",
    verified: true,
    live: true,
    discount: "SAVE",
    discountValue: "₹25K",
  },
];

const tickerMessages = [
  "Rahul just claimed a 20% voucher for Amity Online",
  "Priya saved ₹15,000 on Manipal University admission",
  "Arjun got free certificate from Coursera",
  "Sneha grabbed 90% off on Udemy courses",
  "Vikram applied for NMIMS with waived fees",
  "Ananya enrolled in upGrad Data Science with ₹25K off",
];

export default function UniDeals() {
  const [view, setView] = useState<"public" | "admin">("public");
  const [coupons, setCoupons] = useState<Coupon[]>(initialCoupons);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("All Deals");
  const [selectedCoupon, setSelectedCoupon] = useState<Coupon | null>(null);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminTab, setAdminTab] = useState<"deals" | "leads" | "analytics" | "cms">("deals");
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  // Blog CMS State
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(initialBlogPosts);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [showBlogForm, setShowBlogForm] = useState(false);

  // Coupon Modal State
  const [copied, setCopied] = useState(false);

  // Scroll ref for popular offers
  const scrollRef = useRef<HTMLDivElement>(null);

  // Countdown timers
  const [countdowns, setCountdowns] = useState<Record<number, string>>({});

  // Load blog posts from localStorage
  useEffect(() => {
    const storedPosts = localStorage.getItem("unideals_blog_posts");
    if (storedPosts) {
      setBlogPosts(JSON.parse(storedPosts));
    }
  }, []);

  // Save blog posts to localStorage
  useEffect(() => {
    localStorage.setItem("unideals_blog_posts", JSON.stringify(blogPosts));
  }, [blogPosts]);

  useEffect(() => {
    const updateCountdowns = () => {
      const newCountdowns: Record<number, string> = {};
      coupons.forEach((coupon) => {
        const expiry = new Date(coupon.expiry).getTime();
        const now = Date.now();
        const diff = expiry - now;
        if (diff > 0) {
          const days = Math.floor(diff / (1000 * 60 * 60 * 24));
          const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
          newCountdowns[coupon.id] = `${days}d ${hours}h ${mins}m`;
        } else {
          newCountdowns[coupon.id] = "Expired";
        }
      });
      setCountdowns(newCountdowns);
    };
    updateCountdowns();
    const interval = setInterval(updateCountdowns, 60000);
    return () => clearInterval(interval);
  }, [coupons]);

  // Filter coupons
  const filteredCoupons = coupons.filter((coupon) => {
    const matchesSearch =
      coupon.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      coupon.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTab =
      activeTab === "All Deals" ||
      (activeTab === "University Degrees" && coupon.cat === "University Degrees") ||
      (activeTab === "Skilling Courses" && coupon.cat === "Skilling Courses") ||
      (activeTab === "Expiring Soon" && new Date(coupon.expiry).getTime() - Date.now() < 7 * 24 * 60 * 60 * 1000);
    return matchesSearch && matchesTab && coupon.live;
  });

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -300, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 300, behavior: "smooth" });
    }
  };

  const handleGetCode = (coupon: Coupon) => {
    setSelectedCoupon(coupon);
    setCopied(false);
    // Update coupon stats immediately
    setCoupons((prev) =>
      prev.map((c) =>
        c.id === coupon.id ? { ...c, clicks: c.clicks + 1, conv: c.conv + 1 } : c
      )
    );
  };

  const handleCopyCode = () => {
    if (selectedCoupon) {
      navigator.clipboard.writeText(selectedCoupon.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleAdminLogin = () => {
    if (adminEmail === "admin@unideals.in" && adminPassword === "admin") {
      setIsAdminLoggedIn(true);
    }
  };

  const handleDeleteCoupon = (id: number) => {
    setCoupons((prev) => prev.filter((c) => c.id !== id));
  };

  const handleSaveCoupon = (coupon: Coupon) => {
    if (editingCoupon) {
      setCoupons((prev) => prev.map((c) => (c.id === coupon.id ? coupon : c)));
    } else {
      setCoupons((prev) => [...prev, { ...coupon, id: Date.now() }]);
    }
    setEditingCoupon(null);
    setShowAddForm(false);
  };

  const handleSaveBlogPost = (post: BlogPost) => {
    if (editingPost) {
      setBlogPosts((prev) => prev.map((p) => (p.id === post.id ? post : p)));
    } else {
      // Add new post at the beginning so latest shows first
      setBlogPosts((prev) => [{ ...post, id: Date.now(), publishedAt: new Date().toISOString().split("T")[0] }, ...prev]);
    }
    setEditingPost(null);
    setShowBlogForm(false);
  };

  const handleDeleteBlogPost = (id: number) => {
    setBlogPosts((prev) => prev.filter((p) => p.id !== id));
  };

  const exportCSV = () => {
    const headers = ["ID", "Name", "Email", "Phone", "Coupon Brand", "Timestamp"];
    const rows = leads.map((l) => [l.id, l.name, l.email, l.phone, l.couponBrand, l.timestamp]);
    const csv = [headers, ...rows].map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "leads.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  // Analytics data
  const clicksData = coupons.map((c) => ({ name: c.brand, clicks: c.clicks }));
  const convsData = coupons.map((c) => ({ name: c.brand, conversions: c.conv }));

  // Sort blog posts by date (latest first)
  const sortedBlogPosts = [...blogPosts].sort((a, b) => 
    new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );

  if (view === "admin") {
    if (!isAdminLoggedIn) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
          <Header currentPage="admin" />
          <div className="flex items-center justify-center py-20 px-4">
            <div className="bg-white rounded-3xl shadow-xl p-8 w-full max-w-md border border-gray-100">
              <div className="flex items-center justify-center gap-3 mb-8">
                <Image src="/logo.svg" alt="UniDeals" width={150} height={40} style={{ height: '40px', width: 'auto' }} />
                <span className="text-lg font-semibold text-[#1A1A1A] bg-gray-100 px-3 py-1 rounded-full">Admin</span>
              </div>
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#eb4731] focus:border-transparent transition-all bg-gray-50 focus:bg-white"
                    placeholder="admin@unideals.in"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#eb4731] focus:border-transparent transition-all bg-gray-50 focus:bg-white"
                    placeholder="Enter password"
                  />
                </div>
                <button
                  onClick={handleAdminLogin}
                  className="w-full bg-[#eb4731] text-white py-3.5 rounded-xl font-semibold hover:bg-[#d63d2d] transition-all hover:shadow-lg"
                >
                  Login to Admin Panel
                </button>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-50">
        <Header currentPage="admin" />
        
        {/* Admin Top Bar */}
        <div className="bg-white border-b border-gray-200 sticky top-[57px] z-40">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-lg font-semibold text-[#1A1A1A]">Admin Panel</span>
              <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">Logged in</span>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setView("public")}
                className="text-gray-500 hover:text-gray-700 text-sm font-medium"
              >
                View Site
              </button>
              <button
                onClick={() => {
                  setIsAdminLoggedIn(false);
                  setView("public");
                }}
                className="flex items-center gap-2 text-gray-500 hover:text-[#eb4731] transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Logout</span>
              </button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                  <Gift className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-gray-500 text-xs font-medium">Total Deals</p>
                  <p className="text-2xl font-bold text-[#1A1A1A]">{coupons.length}</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-gray-500 text-xs font-medium">Active Deals</p>
                  <p className="text-2xl font-bold text-[#1A1A1A]">
                    {coupons.filter((c) => c.live).length}
                  </p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-gray-500 text-xs font-medium">Total Leads</p>
                  <p className="text-2xl font-bold text-[#1A1A1A]">{leads.length}</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center">
                  <FileEdit className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-gray-500 text-xs font-medium">Blog Posts</p>
                  <p className="text-2xl font-bold text-[#1A1A1A]">{blogPosts.length}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Admin Tabs */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="border-b border-gray-200 bg-gray-50/50">
              <div className="flex flex-wrap">
                <button
                  onClick={() => setAdminTab("deals")}
                  className={`px-5 py-3.5 font-medium text-sm transition-colors flex items-center gap-2 ${
                    adminTab === "deals"
                      ? "text-[#eb4731] border-b-2 border-[#eb4731] bg-white"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  Manage Deals
                </button>
                <button
                  onClick={() => setAdminTab("leads")}
                  className={`px-5 py-3.5 font-medium text-sm transition-colors flex items-center gap-2 ${
                    adminTab === "leads"
                      ? "text-[#eb4731] border-b-2 border-[#eb4731] bg-white"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <Database className="w-4 h-4" />
                  Lead Database
                </button>
                <button
                  onClick={() => setAdminTab("analytics")}
                  className={`px-5 py-3.5 font-medium text-sm transition-colors flex items-center gap-2 ${
                    adminTab === "analytics"
                      ? "text-[#eb4731] border-b-2 border-[#eb4731] bg-white"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  Analytics
                </button>
                <button
                  onClick={() => setAdminTab("cms")}
                  className={`px-5 py-3.5 font-medium text-sm transition-colors flex items-center gap-2 ${
                    adminTab === "cms"
                      ? "text-[#eb4731] border-b-2 border-[#eb4731] bg-white"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <FileEdit className="w-4 h-4" />
                  Blog CMS
                </button>
              </div>
            </div>

            <div className="p-6">
              {adminTab === "deals" && (
                <>
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-lg font-bold text-[#1A1A1A]">All Deals</h2>
                    <button
                      onClick={() => {
                        setEditingCoupon(null);
                        setShowAddForm(true);
                      }}
                      className="flex items-center gap-2 bg-[#eb4731] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#d63d2d] transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Add Deal
                    </button>
                  </div>

                  {(showAddForm || editingCoupon) && (
                    <CouponForm
                      coupon={editingCoupon}
                      onSave={handleSaveCoupon}
                      onCancel={() => {
                        setEditingCoupon(null);
                        setShowAddForm(false);
                      }}
                    />
                  )}

                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Brand</th>
                          <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Title</th>
                          <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Code</th>
                          <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Category</th>
                          <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Status</th>
                          <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {coupons.map((coupon) => (
                          <tr key={coupon.id} className="border-b border-gray-50 hover:bg-gray-50">
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-3">
                                <div
                                  className={`w-9 h-9 rounded-lg bg-gradient-to-br ${coupon.colorClass} flex items-center justify-center text-white font-bold text-xs`}
                                >
                                  {coupon.initials}
                                </div>
                                <span className="font-medium text-sm">{coupon.brand}</span>
                              </div>
                            </td>
                            <td className="py-3 px-4 text-gray-600 text-sm">{coupon.title}</td>
                            <td className="py-3 px-4">
                              <code className="bg-gray-100 px-2 py-1 rounded text-xs font-mono">
                                {coupon.code}
                              </code>
                            </td>
                            <td className="py-3 px-4 text-gray-500 text-sm">{coupon.cat}</td>
                            <td className="py-3 px-4">
                              <span
                                className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  coupon.live
                                    ? "bg-green-50 text-green-700"
                                    : "bg-gray-100 text-gray-500"
                                }`}
                              >
                                {coupon.live ? "Live" : "Draft"}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => setEditingCoupon(coupon)}
                                  className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                >
                                  <Pencil className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => handleDeleteCoupon(coupon.id)}
                                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}

              {adminTab === "leads" && (
                <>
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-lg font-bold text-[#1A1A1A]">Lead Database</h2>
                    <button
                      onClick={exportCSV}
                      className="flex items-center gap-2 bg-[#0d9e6e] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#0b8a5f] transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      Export CSV
                    </button>
                  </div>

                  {leads.length === 0 ? (
                    <div className="text-center py-12 text-gray-400">
                      <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No leads captured yet</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-gray-200">
                            <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Name</th>
                            <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Email</th>
                            <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">Phone</th>
                            <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">
                              Coupon Brand
                            </th>
                            <th className="text-left py-3 px-4 font-medium text-gray-600 text-sm">
                              Timestamp
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {leads.map((lead) => (
                            <tr key={lead.id} className="border-b border-gray-50 hover:bg-gray-50">
                              <td className="py-3 px-4 font-medium text-sm">{lead.name}</td>
                              <td className="py-3 px-4 text-gray-600 text-sm">{lead.email}</td>
                              <td className="py-3 px-4 text-gray-600 text-sm">{lead.phone}</td>
                              <td className="py-3 px-4 text-gray-600 text-sm">{lead.couponBrand}</td>
                              <td className="py-3 px-4 text-gray-400 text-xs">
                                {new Date(lead.timestamp).toLocaleString()}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              )}

              {adminTab === "analytics" && (
                <>
                  <h2 className="text-lg font-bold text-[#1A1A1A] mb-6">Analytics Overview</h2>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-gray-50 rounded-xl p-5">
                      <h3 className="text-sm font-semibold text-[#1A1A1A] mb-4">Clicks by Partner</h3>
                      <ResponsiveContainer width="100%" height={250}>
                        <BarChart data={clicksData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                          <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                          <YAxis tick={{ fontSize: 11 }} />
                          <Tooltip />
                          <Bar dataKey="clicks" fill="#eb4731" radius={[6, 6, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="bg-gray-50 rounded-xl p-5">
                      <h3 className="text-sm font-semibold text-[#1A1A1A] mb-4">
                        Conversions by Partner
                      </h3>
                      <ResponsiveContainer width="100%" height={250}>
                        <BarChart data={convsData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                          <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                          <YAxis tick={{ fontSize: 11 }} />
                          <Tooltip />
                          <Bar dataKey="conversions" fill="#0d9e6e" radius={[6, 6, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </>
              )}

              {adminTab === "cms" && (
                <>
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-lg font-bold text-[#1A1A1A]">Blog Content Management</h2>
                    <button
                      onClick={() => {
                        setEditingPost(null);
                        setShowBlogForm(true);
                      }}
                      className="flex items-center gap-2 bg-[#eb4731] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#d63d2d] transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      New Post
                    </button>
                  </div>

                  {(showBlogForm || editingPost) && (
                    <BlogPostForm
                      post={editingPost}
                      onSave={handleSaveBlogPost}
                      onCancel={() => {
                        setEditingPost(null);
                        setShowBlogForm(false);
                      }}
                    />
                  )}

                  <div className="space-y-3">
                    {sortedBlogPosts.map((post) => (
                      <div
                        key={post.id}
                        className="bg-gray-50 rounded-xl p-4 flex items-center gap-4 hover:bg-gray-100 transition-colors"
                      >
                        <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-gray-200">
                          {post.coverImage && (
                            <Image
                              src={post.coverImage}
                              alt={post.title}
                              width={64}
                              height={64}
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-[#1A1A1A] text-sm truncate">{post.title}</h3>
                          <p className="text-gray-500 text-xs truncate mt-0.5">{post.excerpt}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <span
                              className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                                post.status === "published"
                                  ? "bg-green-100 text-green-700"
                                  : "bg-yellow-100 text-yellow-700"
                              }`}
                            >
                              {post.status === "published" ? "Published" : "Draft"}
                            </span>
                            <span className="text-gray-400 text-xs">{post.category}</span>
                            <span className="text-gray-400 text-xs">
                              {new Date(post.publishedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => setEditingPost(post)}
                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Edit post"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteBlogPost(post.id)}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete post"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <Footer />
      </div>
    );
  }

  // Public View
  return (
    <div className="min-h-screen bg-gray-50">
      <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} currentPage="home" />

      {/* Hero Section */}
      <section className="relative min-h-[600px] lg:min-h-[700px] overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image
            src="/images/hero-student.jpg"
            alt="Happy student celebrating success"
            fill
            className="object-cover object-center"
            priority
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#272926]/90 via-[#272926]/70 to-transparent"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 py-16 lg:py-24">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium mb-6 border border-white/20">
              <Award className="w-4 h-4" />
              {"India's #1 scholarship and coupon platform"}
            </div>
            <h1 className="text-3xl lg:text-4xl xl:text-5xl font-bold text-white leading-tight mb-5 text-balance">
              Save Big on Your{" "}
              <span className="text-[#eb4731]">Education</span> Journey
            </h1>
            <p className="text-base text-white/80 mb-8 leading-relaxed text-pretty">
              Discover exclusive scholarships, discounts, and vouchers from top universities and
              learning platforms. Join thousands of students saving money on their education.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="#deals"
                className="inline-flex items-center gap-2 bg-[#eb4731] text-white px-6 py-3 rounded-xl font-semibold text-sm hover:bg-[#d63d2d] transition-all hover:-translate-y-1 hover:shadow-xl"
              >
                <Sparkles className="w-4 h-4" />
                Explore Deals
              </a>
              <a
                href="#testimonials"
                className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white px-6 py-3 rounded-xl font-semibold text-sm border border-white/30 hover:bg-white/20 transition-all hover:-translate-y-1"
              >
                See Success Stories
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-10 pt-8 border-t border-white/20">
              {[
                { value: "50,000+", label: "Students Helped" },
                { value: "500+", label: "Active Scholarships" },
                { value: "₹10 Cr+", label: "Saved by Students" },
                { value: "95%", label: "Success Rate" },
              ].map((stat, index) => (
                <div key={index}>
                  <p className="text-xl lg:text-2xl font-bold text-[#eb4731] mb-1">{stat.value}</p>
                  <p className="text-white/70 text-xs">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Live Ticker */}
      <div className="bg-[#272926] py-2.5 overflow-hidden">
        <div className="animate-marquee whitespace-nowrap flex">
          {[...tickerMessages, ...tickerMessages].map((msg, i) => (
            <span key={i} className="mx-8 text-white/90 text-sm">
              {msg.split(/(\b(?:Amity Online|Manipal University|Coursera|Udemy|NMIMS|upGrad)\b)/g).map((part, j) =>
                ["Amity Online", "Manipal University", "Coursera", "Udemy", "NMIMS", "upGrad"].includes(part) ? (
                  <span key={j} className="text-[#eb4731] font-semibold">
                    {part}
                  </span>
                ) : (
                  part
                )
              )}
            </span>
          ))}
        </div>
      </div>

      {/* Popular Offers */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-orange-100 rounded-lg flex items-center justify-center">
                <Flame className="w-5 h-5 text-orange-500" />
              </div>
              <h2 className="text-xl font-bold text-[#1A1A1A]">Popular Offers</h2>
            </div>
            <div className="hidden sm:flex items-center gap-2">
              <button
                onClick={scrollLeft}
                className="p-2 bg-white rounded-lg border border-gray-200 hover:border-[#eb4731] hover:text-[#eb4731] transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={scrollRight}
                className="p-2 bg-white rounded-lg border border-gray-200 hover:border-[#eb4731] hover:text-[#eb4731] transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div
            ref={scrollRef}
            className="flex gap-4 overflow-x-auto snap-x snap-mandatory pop-scroll pb-4"
          >
            {coupons
              .filter((c) => c.live && (c.isPopular !== false))
              .sort((a, b) => (a.order ?? 999) - (b.order ?? 999))
              .map((coupon) => (
                <div
                  key={coupon.id}
                  className="flex-shrink-0 w-80 snap-start group"
                >
                  <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden transition-all hover:-translate-y-2 hover:shadow-2xl hover:border-[#eb4731]/30">
                    {/* Main Content Area */}
                    <div className="flex">
                      {/* Discount Section - Left */}
                      <div className="w-28 flex-shrink-0 flex flex-col items-center justify-center py-6 px-3 border-r border-dashed border-gray-200">
                        <span className="text-[#3b82f6] text-xs font-semibold uppercase tracking-wide">
                          {coupon.discount || "UP TO"}
                        </span>
                        <span className="text-[#3b82f6] text-3xl font-bold leading-none my-1">
                          {coupon.discountValue || `${coupon.success}%`}
                        </span>
                        <span className="text-[#3b82f6] text-xs font-semibold uppercase tracking-wide">
                          OFF
                        </span>
                      </div>
                      
                      {/* Description Section - Right */}
                      <div className="flex-1 py-6 px-4 flex items-center">
                        <p className="text-[#1A1A1A] text-sm leading-relaxed">
                          {coupon.brand} Coupon : {coupon.title}
                        </p>
                      </div>
                    </div>
                    
                    {/* Footer with Logo and Link */}
                    <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 bg-gray-50/50">
                      <div className="flex items-center gap-2">
                        {coupon.image ? (
                          <div className="w-8 h-8 rounded-lg overflow-hidden bg-white border border-gray-100">
                            <Image src={coupon.image} alt={coupon.brand} width={32} height={32} className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <div className="w-8 h-8 bg-[#272926] rounded-lg flex items-center justify-center text-white font-bold text-xs">
                            {coupon.initials}
                          </div>
                        )}
                        <span className="text-[#1A1A1A] text-sm font-medium">{coupon.brand}</span>
                      </div>
                      <button
                        onClick={() => handleGetCode(coupon)}
                        className="flex items-center gap-1.5 text-[#3b82f6] text-sm font-medium hover:text-[#2563eb] transition-colors"
                      >
                        View All {coupon.brand} Coupons
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </section>

      {/* Top Deals */}
      <section id="deals" className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-2xl lg:text-3xl font-bold text-[#1A1A1A] mb-3">Top Deals</h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-sm">
              Handpicked offers verified by our team. Get exclusive discounts on top education platforms.
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {["All Deals", "University Degrees", "Skilling Courses", "Expiring Soon"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  activeTab === tab
                    ? "bg-[#eb4731] text-white shadow-lg"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Deals Grid - Cards matching reference design */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredCoupons.map((coupon) => (
              <div
                key={coupon.id}
                className="bg-white border border-gray-200 rounded-2xl overflow-hidden hover:shadow-xl hover:border-[#eb4731]/30 transition-all group"
              >
                {/* Main Content Area */}
                <div className="flex">
                  {/* Discount Section - Left */}
                  <div className="w-28 flex-shrink-0 flex flex-col items-center justify-center py-6 px-3 border-r border-dashed border-gray-200">
                    <span className="text-[#3b82f6] text-xs font-semibold uppercase tracking-wide">
                      {coupon.discount || "UP TO"}
                    </span>
                    <span className="text-[#3b82f6] text-3xl font-bold leading-none my-1">
                      {coupon.discountValue || `${coupon.success}%`}
                    </span>
                    <span className="text-[#3b82f6] text-xs font-semibold uppercase tracking-wide">
                      OFF
                    </span>
                  </div>
                  
                  {/* Description Section - Right */}
                  <div className="flex-1 py-6 px-4 flex items-center">
                    <p className="text-[#1A1A1A] text-sm leading-relaxed">
                      {coupon.brand} Coupon : {coupon.title}
                    </p>
                  </div>
                </div>
                
                {/* Footer with Logo and Link */}
                <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 bg-gray-50/50">
                  <div className="flex items-center gap-2">
                    {coupon.image ? (
                      <div className="w-8 h-8 rounded-lg overflow-hidden bg-white border border-gray-100">
                        <Image src={coupon.image} alt={coupon.brand} width={32} height={32} className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 bg-[#272926] rounded-lg flex items-center justify-center text-white font-bold text-xs">
                        {coupon.initials}
                      </div>
                    )}
                    <span className="text-[#1A1A1A] text-sm font-medium">{coupon.brand}</span>
                  </div>
                  <button
                    onClick={() => handleGetCode(coupon)}
                    className="flex items-center gap-1.5 text-[#3b82f6] text-sm font-medium hover:text-[#2563eb] transition-colors"
                  >
                    View All {coupon.brand} Coupons
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredCoupons.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              <Gift className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No deals found matching your criteria</p>
            </div>
          )}
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-16 bg-[#272926] relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-[#eb4731]/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <h2 className="text-2xl lg:text-3xl font-bold text-white mb-3">
              What Students Say
            </h2>
            <p className="text-white/80 max-w-2xl mx-auto text-sm">
              Real stories from students who saved big with UniDeals
            </p>
          </div>

          {/* Horizontal Scrollable Cards */}
          <div className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide -mx-4 px-4">
            {[
              {
                name: "Priya Sharma",
                role: "MBA Student, Amity",
                initials: "PS",
                review:
                  "UniDeals helped me save ₹45,000 on my MBA fees! The process was super simple and the code worked instantly.",
                saved: "₹45,000",
              },
              {
                name: "Rahul Kumar",
                role: "Data Science Learner",
                initials: "RK",
                review:
                  "Got an amazing 90% discount on Udemy courses. I have completed 5 certifications already thanks to UniDeals!",
                saved: "₹12,000",
              },
              {
                name: "Ananya Patel",
                role: "BCA Student, Manipal",
                initials: "AP",
                review:
                  "The ₹15,000 scholarship from Manipal was life-changing. UniDeals made it so easy to find and apply.",
                saved: "₹15,000",
              },
              {
                name: "Vikram Singh",
                role: "Engineering Student",
                initials: "VS",
                review:
                  "Found amazing deals on programming courses. The 80% off on Coursera was unbelievable!",
                saved: "₹8,500",
              },
              {
                name: "Sneha Reddy",
                role: "Medical Student",
                initials: "SR",
                review:
                  "Medical books are expensive, but UniDeals got me 60% off. Highly recommend to all students!",
                saved: "₹22,000",
              },
            ].map((testimonial, index) => (
              <div
                key={index}
                className="flex-shrink-0 w-80 snap-center bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all group"
              >
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-[#1A1A1A] italic mb-6 text-sm leading-relaxed">{`"${testimonial.review}"`}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-[#eb4731] rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {testimonial.initials}
                    </div>
                    <div>
                      <p className="font-semibold text-[#1A1A1A] text-sm">{testimonial.name}</p>
                      <p className="text-gray-500 text-xs">{testimonial.role}</p>
                    </div>
                  </div>
                  <div className="bg-green-100 px-3 py-1 rounded-full">
                    <p className="text-green-700 text-xs font-semibold">Saved {testimonial.saved}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Scroll indicator */}
          <div className="flex justify-center mt-6 gap-2">
            <div className="w-8 h-1 bg-[#eb4731] rounded-full"></div>
            <div className="w-2 h-1 bg-white/20 rounded-full"></div>
            <div className="w-2 h-1 bg-white/20 rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-[#eb4731] rounded-2xl p-8 lg:p-10 relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 left-0 w-32 h-32 bg-white rounded-full -translate-x-1/2 -translate-y-1/2"></div>
              <div className="absolute bottom-0 right-0 w-48 h-48 bg-white rounded-full translate-x-1/4 translate-y-1/4"></div>
            </div>

            <div className="relative z-10 text-center">
              <h2 className="text-2xl lg:text-3xl font-bold text-white mb-3 text-balance">
                Ready to Start Saving on Your Education?
              </h2>
              <p className="text-white/90 mb-6 max-w-2xl mx-auto text-sm">
                Join thousands of students who are already saving big with UniDeals.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <a
                  href="#deals"
                  className="inline-flex items-center gap-2 bg-white text-[#eb4731] px-6 py-3 rounded-xl font-semibold text-sm hover:bg-gray-100 transition-all hover:-translate-y-1"
                >
                  Browse All Deals
                </a>
                <a
                  href="/contact"
                  className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm text-white px-6 py-3 rounded-xl font-semibold text-sm border border-white/30 hover:bg-white/30 transition-all"
                >
                  Contact Us
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer onAdminClick={() => setView("admin")} />

      {/* Coupon Code Modal - Ticket/Coupon Style */}
      {selectedCoupon && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-300 relative">
            {/* Close button */}
            <button
              onClick={() => setSelectedCoupon(null)}
              className="absolute top-3 right-3 z-10 w-8 h-8 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center text-gray-500 hover:text-gray-700 hover:bg-white transition-all"
            >
              <span className="sr-only">Close</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>

            {/* Coupon Card Design */}
            <div className="relative">
              {/* Top section with brand info */}
              <div className="bg-[#eb4731] p-6 pb-8">
                <div className="flex items-center gap-4">
                  {selectedCoupon.image ? (
                    <div className="w-14 h-14 rounded-xl overflow-hidden bg-white flex items-center justify-center">
                      <Image src={selectedCoupon.image} alt={selectedCoupon.brand} width={56} height={56} className="w-full h-full object-cover" />
                    </div>
                  ) : (
                    <div className="w-14 h-14 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center text-white font-bold text-lg">
                      {selectedCoupon.initials}
                    </div>
                  )}
                  <div className="text-white flex-1">
                    <p className="font-bold text-lg">{selectedCoupon.brand}</p>
                    <p className="text-white/90 text-sm">{selectedCoupon.title}</p>
                  </div>
                </div>
                
                {/* Verified badge */}
                {selectedCoupon.verified && (
                  <div className="flex items-center gap-1.5 mt-4 text-white/90 text-sm">
                    <BadgeCheck className="w-4 h-4" />
                    <span>Verified Deal</span>
                  </div>
                )}
              </div>

              {/* Perforated edge effect */}
              <div className="absolute left-0 right-0 top-[calc(100%-12px)] flex justify-between px-0">
                <div className="w-6 h-6 bg-black/50 rounded-full -ml-3"></div>
                <div className="flex-1 border-t-2 border-dashed border-gray-300 mt-3 mx-1"></div>
                <div className="w-6 h-6 bg-black/50 rounded-full -mr-3"></div>
              </div>
            </div>

            {/* Code Section */}
            <div className="p-6 pt-8 text-center">
              <p className="text-gray-500 text-sm mb-3">Your exclusive coupon code</p>
              
              {/* Code Display - Ticket style */}
              <div className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-xl p-5 mb-5">
                <p className="text-2xl font-mono font-bold text-[#1A1A1A] tracking-widest">
                  {selectedCoupon.code}
                </p>
              </div>

              {/* Copy Button */}
              <button
                onClick={handleCopyCode}
                className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold transition-all text-sm ${
                  copied
                    ? "bg-green-100 text-green-700"
                    : "bg-[#eb4731] text-white hover:bg-[#d63d2d]"
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4" />
                    Copied to Clipboard!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    Copy Coupon Code
                  </>
                )}
              </button>

              {/* Expiry info */}
              <div className="mt-4 flex items-center justify-center gap-2 text-gray-500 text-xs">
                <Clock className="w-3.5 h-3.5" />
                <span>Expires: {countdowns[selectedCoupon.id] || "Loading..."}</span>
              </div>

              {/* Success rate */}
              <div className="mt-3 flex items-center justify-center gap-2 text-[#0d9e6e] text-xs font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{selectedCoupon.success}% success rate</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Coupon Form Component for Admin
function CouponForm({
  coupon,
  onSave,
  onCancel,
}: {
  coupon: Coupon | null;
  onSave: (coupon: Coupon) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState<Coupon>(
    coupon || {
      id: 0,
      brand: "",
      title: "",
      desc: "",
      initials: "",
      colorClass: "from-blue-500 to-blue-700",
      tags: [],
      cat: "University Degrees",
      success: 90,
      clicks: 0,
      conv: 0,
      expiry: "",
      code: "",
      verified: true,
      live: false,
      image: "",
      isPopular: true,
      order: 0,
    }
  );
  const [tagInput, setTagInput] = useState(coupon?.tags.join(", ") || "");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const initials = formData.brand
      .split(" ")
      .map((w) => w[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
    const tags = tagInput.split(",").map((t) => t.trim()).filter(Boolean);
    onSave({ ...formData, initials, tags });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 rounded-xl p-5 mb-6">
      <h3 className="text-base font-semibold text-[#1A1A1A] mb-4">
        {coupon ? "Edit Deal" : "Add New Deal"}
      </h3>
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Brand Name</label>
          <input
            type="text"
            value={formData.brand}
            onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Coupon Code</label>
          <input
            type="text"
            value={formData.code}
            onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm font-mono focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Tags (comma separated)</label>
          <input
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            placeholder="MBA, Online, Tech"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
          <select
            value={formData.cat}
            onChange={(e) => setFormData({ ...formData, cat: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
          >
            <option value="University Degrees">University Degrees</option>
            <option value="Skilling Courses">Skilling Courses</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
          <input
            type="date"
            value={formData.expiry}
            onChange={(e) => setFormData({ ...formData, expiry: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            required
          />
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea
            value={formData.desc}
            onChange={(e) => setFormData({ ...formData, desc: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            rows={2}
          />
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <ImageIcon className="w-3.5 h-3.5 inline mr-1" />
            Brand Logo/Image URL
          </label>
          <input
            type="url"
            value={formData.image || ""}
            onChange={(e) => setFormData({ ...formData, image: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            placeholder="https://example.com/logo.png"
          />
          <p className="text-xs text-gray-500 mt-1">Optional: Add a brand logo or image URL to display instead of initials</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Display Order</label>
          <input
            type="number"
            value={formData.order || 0}
            onChange={(e) => setFormData({ ...formData, order: parseInt(e.target.value) || 0 })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            min="0"
            placeholder="0"
          />
          <p className="text-xs text-gray-500 mt-1">Lower number = higher priority in Popular section</p>
        </div>
        <div className="flex items-center gap-6 flex-wrap">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.live}
              onChange={(e) => setFormData({ ...formData, live: e.target.checked })}
              className="w-4 h-4 text-[#eb4731] border-gray-200 rounded focus:ring-[#eb4731]"
            />
            <span className="text-sm text-gray-700">Live</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.verified}
              onChange={(e) => setFormData({ ...formData, verified: e.target.checked })}
              className="w-4 h-4 text-[#eb4731] border-gray-200 rounded focus:ring-[#eb4731]"
            />
            <span className="text-sm text-gray-700">Verified</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.isPopular !== false}
              onChange={(e) => setFormData({ ...formData, isPopular: e.target.checked })}
              className="w-4 h-4 text-[#eb4731] border-gray-200 rounded focus:ring-[#eb4731]"
            />
            <span className="text-sm text-gray-700">Show in Popular Offers</span>
          </label>
        </div>
      </div>
      <div className="flex justify-end gap-3 mt-5">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-gray-500 hover:text-gray-700 font-medium text-sm transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-5 py-2 bg-[#eb4731] text-white rounded-lg font-medium text-sm hover:bg-[#d63d2d] transition-colors"
        >
          {coupon ? "Update Deal" : "Add Deal"}
        </button>
      </div>
    </form>
  );
}

// Blog Post Form Component for Admin
function BlogPostForm({
  post,
  onSave,
  onCancel,
}: {
  post: BlogPost | null;
  onSave: (post: BlogPost) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState<BlogPost>(
    post || {
      id: 0,
      title: "",
      slug: "",
      excerpt: "",
      content: "",
      coverImage: "",
      author: "",
      authorInitials: "",
      publishedAt: new Date().toISOString().split("T")[0],
      status: "draft",
      category: "Education",
      readTime: "5 min read",
      keywords: "",
    }
  );

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const authorInitials = formData.author
      .split(" ")
      .map((w) => w[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
    const slug = formData.slug || generateSlug(formData.title);
    onSave({ ...formData, authorInitials, slug });
  };

  const insertFormatting = (tag: string) => {
    const textarea = document.getElementById("content-editor") as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = formData.content.substring(start, end);
    
    let wrappedText = "";
    switch (tag) {
      case "h2":
        wrappedText = `<h2>${selectedText || "Heading"}</h2>`;
        break;
      case "bold":
        wrappedText = `<strong>${selectedText || "bold text"}</strong>`;
        break;
      case "italic":
        wrappedText = `<em>${selectedText || "italic text"}</em>`;
        break;
      case "p":
        wrappedText = `<p>${selectedText || "Paragraph text"}</p>`;
        break;
      case "list":
        wrappedText = `<ul>\n  <li>${selectedText || "List item"}</li>\n</ul>`;
        break;
      default:
        wrappedText = selectedText;
    }

    const newContent =
      formData.content.substring(0, start) +
      wrappedText +
      formData.content.substring(end);
    
    setFormData({ ...formData, content: newContent });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 rounded-xl p-5 mb-6">
      <h3 className="text-base font-semibold text-[#1A1A1A] mb-4">
        {post ? "Edit Blog Post" : "Create New Blog Post"}
      </h3>
      
      <div className="grid gap-4">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => {
                const title = e.target.value;
                setFormData({ 
                  ...formData, 
                  title,
                  slug: generateSlug(title)
                });
              }}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Author</label>
            <input
              type="text"
              value={formData.author}
              onChange={(e) => setFormData({ ...formData, author: e.target.value })}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
              required
            />
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            >
              <option value="Education">Education</option>
              <option value="Scholarships">Scholarships</option>
              <option value="Tips & Guides">Tips & Guides</option>
              <option value="Career">Career</option>
              <option value="News">News</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Read Time</label>
            <input
              type="text"
              value={formData.readTime}
              onChange={(e) => setFormData({ ...formData, readTime: e.target.value })}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
              placeholder="5 min read"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as "draft" | "published" })}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            >
              <option value="draft">Draft</option>
              <option value="published">Published</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <ImageIcon className="w-3.5 h-3.5 inline mr-1" />
            Cover Image URL
          </label>
          <input
            type="url"
            value={formData.coverImage}
            onChange={(e) => setFormData({ ...formData, coverImage: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            placeholder="https://images.unsplash.com/..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">SEO Keywords (comma separated)</label>
          <input
            type="text"
            value={formData.keywords || ""}
            onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            placeholder="scholarships, education, ChatGPT, Gemini, Claude..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Excerpt</label>
          <textarea
            value={formData.excerpt}
            onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent"
            rows={2}
            placeholder="Brief summary of the article..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Content (HTML)</label>
          {/* Visual Editor Toolbar */}
          <div className="flex items-center gap-1 bg-white border border-b-0 border-gray-200 rounded-t-lg p-2">
            <button
              type="button"
              onClick={() => insertFormatting("h2")}
              className="p-1.5 hover:bg-gray-100 rounded transition-colors"
              title="Heading"
            >
              <Heading2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting("bold")}
              className="p-1.5 hover:bg-gray-100 rounded transition-colors"
              title="Bold"
            >
              <Bold className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting("italic")}
              className="p-1.5 hover:bg-gray-100 rounded transition-colors"
              title="Italic"
            >
              <Italic className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting("p")}
              className="p-1.5 hover:bg-gray-100 rounded transition-colors"
              title="Paragraph"
            >
              <AlignLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting("list")}
              className="p-1.5 hover:bg-gray-100 rounded transition-colors"
              title="List"
            >
              <List className="w-4 h-4" />
            </button>
            <div className="flex-1"></div>
            <span className="text-xs text-gray-400">HTML supported</span>
          </div>
          <textarea
            id="content-editor"
            value={formData.content}
            onChange={(e) => setFormData({ ...formData, content: e.target.value })}
            className="w-full px-4 py-3 border border-gray-200 rounded-b-lg text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent font-mono"
            rows={10}
            placeholder="<h2>Introduction</h2>&#10;<p>Your content here...</p>"
            required
          />
        </div>

        {/* Live Preview */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Preview</label>
          <div className="bg-white border border-gray-200 rounded-lg p-5 max-h-52 overflow-y-auto">
            {formData.content ? (
              <div
                className="prose prose-sm max-w-none"
                dangerouslySetInnerHTML={{ __html: formData.content }}
              />
            ) : (
              <p className="text-gray-400 italic text-sm">Content preview will appear here...</p>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-3 mt-5">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-gray-500 hover:text-gray-700 font-medium text-sm transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="flex items-center gap-2 px-5 py-2 bg-[#eb4731] text-white rounded-lg font-medium text-sm hover:bg-[#d63d2d] transition-colors"
        >
          <Save className="w-4 h-4" />
          {post ? "Update Post" : "Save Post"}
        </button>
      </div>
    </form>
  );
}
