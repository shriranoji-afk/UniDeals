"use client";

import { useState, useEffect, use } from "react";
import Link from "next/link";
import Image from "next/image";
import { Header, Footer, BlogPost, initialBlogPosts } from "@/components/shared";
import { ArrowLeft, Clock, Calendar, Share2, Twitter, Facebook, Linkedin, BookOpen } from "lucide-react";

export default function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const [post, setPost] = useState<BlogPost | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<BlogPost[]>([]);

  useEffect(() => {
    // Load posts from localStorage if available, otherwise use initial posts
    const storedPosts = localStorage.getItem("unideals_blog_posts");
    const allPosts: BlogPost[] = storedPosts ? JSON.parse(storedPosts) : initialBlogPosts;
    
    const currentPost = allPosts.find((p) => p.slug === slug && p.status === "published");
    setPost(currentPost || null);

    if (currentPost) {
      const related = allPosts
        .filter((p) => p.id !== currentPost.id && p.status === "published")
        .slice(0, 3);
      setRelatedPosts(related);
    }
  }, [slug]);

  if (!post) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header currentPage="blog" />
        <div className="max-w-3xl mx-auto px-4 py-24 text-center">
          <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-[#1A1A1A] mb-4">Article Not Found</h1>
          <p className="text-gray-600 mb-8">The article you are looking for does not exist or has been removed.</p>
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 bg-[#eb4731] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#d63d2d] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Blog
          </Link>
        </div>
        <Footer onAdminClick={undefined} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header currentPage="blog" />

      {/* Article Hero */}
      <article>
        <div className="relative h-[50vh] min-h-[400px]">
          <Image
            src={post.coverImage}
            alt={post.title}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
          <div className="absolute inset-0 flex items-end">
            <div className="max-w-4xl mx-auto px-4 pb-12 w-full">
              <Link
                href="/blog"
                className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-4 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Blog
              </Link>
              <div className="flex items-center gap-4 mb-4">
                <span className="bg-[#eb4731] text-white px-3 py-1 rounded-full text-sm font-medium">
                  {post.category}
                </span>
                <span className="flex items-center gap-1 text-white/80 text-sm">
                  <Clock className="w-4 h-4" />
                  {post.readTime}
                </span>
                <span className="flex items-center gap-1 text-white/80 text-sm">
                  <Calendar className="w-4 h-4" />
                  {new Date(post.publishedAt).toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </span>
              </div>
              <h1 className="text-3xl lg:text-5xl font-bold text-white mb-6 text-balance">
                {post.title}
              </h1>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#eb4731] rounded-full flex items-center justify-center text-white font-bold">
                  {post.authorInitials}
                </div>
                <div>
                  <p className="font-medium text-white">{post.author}</p>
                  <p className="text-white/70 text-sm">UniDeals Contributor</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-sm">
            {/* Social Share */}
            <div className="flex items-center gap-4 mb-8 pb-8 border-b border-gray-200">
              <span className="flex items-center gap-2 text-gray-600">
                <Share2 className="w-5 h-5" />
                Share:
              </span>
              <button className="w-10 h-10 bg-[#1DA1F2] rounded-full flex items-center justify-center text-white hover:opacity-80 transition-opacity">
                <Twitter className="w-5 h-5" />
              </button>
              <button className="w-10 h-10 bg-[#4267B2] rounded-full flex items-center justify-center text-white hover:opacity-80 transition-opacity">
                <Facebook className="w-5 h-5" />
              </button>
              <button className="w-10 h-10 bg-[#0077B5] rounded-full flex items-center justify-center text-white hover:opacity-80 transition-opacity">
                <Linkedin className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div
              className="prose prose-lg max-w-none prose-headings:text-[#1A1A1A] prose-p:text-gray-600 prose-a:text-[#eb4731] prose-strong:text-[#1A1A1A]"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </div>
        </div>
      </article>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-[#1A1A1A] mb-8">Related Articles</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {relatedPosts.map((relatedPost) => (
                <Link
                  key={relatedPost.id}
                  href={`/blog/${relatedPost.slug}`}
                  className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all"
                >
                  <div className="relative h-48">
                    <Image
                      src={relatedPost.coverImage}
                      alt={relatedPost.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6">
                    <span className="bg-red-50 text-[#eb4731] px-3 py-1 rounded-full text-xs font-medium">
                      {relatedPost.category}
                    </span>
                    <h3 className="text-lg font-bold text-[#1A1A1A] mt-3 mb-2 group-hover:text-[#eb4731] transition-colors line-clamp-2">
                      {relatedPost.title}
                    </h3>
                    <p className="text-gray-600 text-sm line-clamp-2">{relatedPost.excerpt}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer onAdminClick={undefined} />
    </div>
  );
}
