"use client";

import Image from "next/image";
import { Header, Footer } from "@/components/shared";
import { Users, Target, Award, Heart, Lightbulb, Shield } from "lucide-react";

const teamMembers = [
  {
    name: "Vikram Singh",
    role: "Founder & CEO",
    initials: "VS",
    bio: "Former education consultant with 10+ years experience helping students find scholarships.",
  },
  {
    name: "Priya Mehta",
    role: "Head of Partnerships",
    initials: "PM",
    bio: "Built partnerships with 100+ universities and learning platforms.",
  },
  {
    name: "Arjun Nair",
    role: "CTO",
    initials: "AN",
    bio: "Tech veteran focused on building seamless user experiences.",
  },
  {
    name: "Sneha Reddy",
    role: "Head of Content",
    initials: "SR",
    bio: "Education blogger and scholarship expert with a passion for student success.",
  },
];

const values = [
  {
    icon: Heart,
    title: "Student First",
    desc: "Every decision we make starts with one question: How does this help students?",
  },
  {
    icon: Shield,
    title: "Trust & Transparency",
    desc: "We only partner with verified institutions and always show real success rates.",
  },
  {
    icon: Lightbulb,
    title: "Innovation",
    desc: "Constantly improving our platform to make finding deals easier than ever.",
  },
];

const stats = [
  { value: "50,000+", label: "Students Helped" },
  { value: "100+", label: "Partner Institutions" },
  { value: "₹10 Cr+", label: "Scholarships Disbursed" },
  { value: "95%", label: "Success Rate" },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header currentPage="about" />

      {/* Hero Section */}
      <section className="bg-white py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-red-50 text-[#eb4731] px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Target className="w-4 h-4" />
                Our Mission
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold text-[#1A1A1A] leading-tight mb-6 text-balance">
                Making Education <span className="text-[#eb4731]">Affordable</span> for Everyone
              </h1>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed text-pretty">
                UniDeals was founded with a simple mission: to help every Indian student access quality
                education without financial barriers. We aggregate the best scholarships, discounts, and
                vouchers from top institutions to make your educational journey more affordable.
              </p>
            </div>
            <div className="relative hidden lg:block">
              <div className="absolute inset-0 bg-gradient-to-br from-red-100 to-orange-100 rounded-3xl transform rotate-3"></div>
              <div className="relative rounded-3xl overflow-hidden transform -rotate-3 hover:rotate-0 transition-transform duration-500">
                <Image
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&q=80"
                  alt="Team collaboration"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-[#eb4731] py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <p className="text-3xl lg:text-4xl font-bold text-white mb-2">{stat.value}</p>
                <p className="text-white/80">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 lg:py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1A1A1A] mb-4">Our Story</h2>
          </div>
          <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-sm">
            <p className="text-gray-600 leading-relaxed mb-6">
              UniDeals started in 2023 when our founder, Vikram Singh, noticed a troubling pattern during
              his years as an education consultant: countless talented students were missing out on
              scholarships simply because they did not know they existed.
            </p>
            <p className="text-gray-600 leading-relaxed mb-6">
              He realized that while institutions were eager to offer financial aid, students were
              struggling to find and compare these opportunities. The information was scattered across
              hundreds of websites, making it nearly impossible for students to discover the best deals.
            </p>
            <p className="text-gray-600 leading-relaxed">
              {"That's why we built UniDeals - a single platform where students can discover, compare, and"}{" "}
              {"claim exclusive discounts from India's top universities and learning platforms. Today, we've"}
              helped over 50,000 students save on their education, and we are just getting started.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1A1A1A] mb-4">Our Values</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              These principles guide everything we do at UniDeals.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-2xl p-8 text-center hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <value.icon className="w-8 h-8 text-[#eb4731]" />
                </div>
                <h3 className="text-xl font-bold text-[#1A1A1A] mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 lg:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-red-50 text-[#eb4731] px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Users className="w-4 h-4" />
              Meet the Team
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1A1A1A] mb-4">
              The People Behind UniDeals
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our passionate team is dedicated to helping students achieve their educational dreams.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-white rounded-2xl p-6 text-center shadow-sm hover:shadow-lg transition-shadow">
                <div className="w-20 h-20 bg-[#eb4731] rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
                  {member.initials}
                </div>
                <h3 className="text-lg font-bold text-[#1A1A1A] mb-1">{member.name}</h3>
                <p className="text-[#eb4731] text-sm font-medium mb-3">{member.role}</p>
                <p className="text-gray-600 text-sm">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Awards */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-red-50 text-[#eb4731] px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Award className="w-4 h-4" />
              Recognition
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1A1A1A] mb-4">
              Awards & Recognition
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-2xl p-6 text-center">
              <div className="text-4xl mb-4">🏆</div>
              <h3 className="font-bold text-[#1A1A1A] mb-2">EdTech Startup of the Year</h3>
              <p className="text-gray-500 text-sm">India EdTech Awards 2025</p>
            </div>
            <div className="bg-gray-50 rounded-2xl p-6 text-center">
              <div className="text-4xl mb-4">⭐</div>
              <h3 className="font-bold text-[#1A1A1A] mb-2">Best Student Platform</h3>
              <p className="text-gray-500 text-sm">Education Excellence Awards 2025</p>
            </div>
            <div className="bg-gray-50 rounded-2xl p-6 text-center">
              <div className="text-4xl mb-4">🚀</div>
              <h3 className="font-bold text-[#1A1A1A] mb-2">Top 50 Startups</h3>
              <p className="text-gray-500 text-sm">Economic Times Startup Awards 2024</p>
            </div>
          </div>
        </div>
      </section>

      <Footer onAdminClick={undefined} />
    </div>
  );
}
