"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { Search, Menu, X } from "lucide-react";

// Types
export interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  author: string;
  authorInitials: string;
  publishedAt: string;
  status: "draft" | "published";
  category: string;
  readTime: string;
  keywords?: string;
}

// Initial Blog Posts with SEO keywords
export const initialBlogPosts: BlogPost[] = [
  {
    id: 1,
    title: "Top 10 Scholarships for Indian Students in 2026",
    slug: "top-10-scholarships-indian-students-2026",
    excerpt: "Discover the best scholarship opportunities available for Indian students this year. From government schemes to private foundations.",
    content: `<h2>Introduction</h2><p>Finding the right scholarship can transform your educational journey. In 2026, there are more opportunities than ever for Indian students to fund their education.</p><h2>1. INSPIRE Scholarship</h2><p>The Innovation in Science Pursuit for Inspired Research (INSPIRE) scholarship is one of the most prestigious government scholarships available.</p><h2>2. Tata Trusts Scholarships</h2><p>Tata Trusts offers various scholarships across different educational levels and disciplines.</p><h2>3. Reliance Foundation Scholarships</h2><p>For students pursuing undergraduate studies in India, this scholarship provides substantial financial support.</p><p>Stay tuned for more scholarship updates and tips on how to apply successfully!</p>`,
    coverImage: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&q=80",
    author: "Priya Sharma",
    authorInitials: "PS",
    publishedAt: "2026-04-10",
    status: "published",
    category: "Scholarships",
    readTime: "5 min read",
    keywords: "scholarships India, student scholarships 2026, INSPIRE scholarship, Tata scholarships, education funding, ChatGPT scholarships, AI education",
  },
  {
    id: 2,
    title: "How to Write a Winning Scholarship Essay",
    slug: "how-to-write-winning-scholarship-essay",
    excerpt: "Learn the secrets to crafting compelling scholarship essays that stand out from the competition.",
    content: `<h2>The Art of Scholarship Essays</h2><p>Your scholarship essay is often the deciding factor in your application. Here's how to make it shine.</p><h2>Start with a Hook</h2><p>Begin your essay with an engaging opening that captures attention immediately.</p><h2>Tell Your Story</h2><p>Share genuine experiences that shaped who you are and your educational goals.</p><h2>Be Specific</h2><p>Avoid vague statements. Use concrete examples and achievements.</p><h2>Proofread Multiple Times</h2><p>Grammar and spelling errors can cost you the scholarship. Always proofread!</p>`,
    coverImage: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=800&q=80",
    author: "Rahul Kumar",
    authorInitials: "RK",
    publishedAt: "2026-04-08",
    status: "published",
    category: "Tips & Guides",
    readTime: "7 min read",
    keywords: "scholarship essay tips, how to write scholarship essay, winning essay, college application, Gemini writing tips, Claude AI essay",
  },
  {
    id: 3,
    title: "Online vs Traditional Degrees: What's Right for You?",
    slug: "online-vs-traditional-degrees",
    excerpt: "A comprehensive comparison to help you choose between online and traditional education paths.",
    content: `<h2>The Education Landscape is Changing</h2><p>With the rise of online learning platforms, students now have more choices than ever.</p><h2>Benefits of Online Degrees</h2><p>Flexibility, affordability, and the ability to learn at your own pace are key advantages.</p><h2>Benefits of Traditional Degrees</h2><p>Campus experience, networking opportunities, and hands-on learning remain valuable.</p><h2>Making Your Decision</h2><p>Consider your learning style, career goals, and personal circumstances when choosing.</p>`,
    coverImage: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=800&q=80",
    author: "Ananya Patel",
    authorInitials: "AP",
    publishedAt: "2026-04-05",
    status: "published",
    category: "Education",
    readTime: "6 min read",
    keywords: "online degree vs traditional, online MBA, distance learning India, Coursera degrees, upGrad courses, ChatGPT learning",
  },
];

// Legal Content
export const legalContent = {
  privacy: {
    title: "Privacy Policy",
    content: `<h2>Privacy Policy</h2>
<p><strong>Last Updated:</strong> April 12, 2026</p>

<h3>1. Information We Collect</h3>
<p>We collect information you provide directly to us, such as when you create an account, fill out a form, or contact us. This may include:</p>
<ul>
<li>Name and email address</li>
<li>Phone number</li>
<li>Educational interests and preferences</li>
<li>Usage data and browsing behavior</li>
</ul>

<h3>2. How We Use Your Information</h3>
<p>We use the information we collect to:</p>
<ul>
<li>Provide, maintain, and improve our services</li>
<li>Send you relevant scholarship and deal notifications</li>
<li>Respond to your comments and questions</li>
<li>Analyze usage patterns to improve user experience</li>
</ul>

<h3>3. Information Sharing</h3>
<p>We may share your information with partner educational institutions when you request a coupon code. We do not sell your personal information to third parties.</p>

<h3>4. Data Security</h3>
<p>We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.</p>

<h3>5. Contact Us</h3>
<p>If you have questions about this Privacy Policy, please contact us at privacy@unideals.in</p>`,
  },
  terms: {
    title: "Terms of Service",
    content: `<h2>Terms of Service</h2>
<p><strong>Last Updated:</strong> April 12, 2026</p>

<h3>1. Acceptance of Terms</h3>
<p>By accessing and using UniDeals, you accept and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our platform.</p>

<h3>2. Description of Service</h3>
<p>UniDeals provides a platform for discovering educational scholarships, discounts, and coupon codes from partner institutions. We act as an intermediary and do not directly provide educational services.</p>

<h3>3. User Responsibilities</h3>
<ul>
<li>Provide accurate information when registering</li>
<li>Use coupon codes only for personal educational purposes</li>
<li>Not share or resell obtained codes</li>
<li>Comply with partner institution terms</li>
</ul>

<h3>4. Disclaimer</h3>
<p>Coupon codes and scholarships are subject to availability and partner institution terms. UniDeals does not guarantee the validity or success of any offer.</p>

<h3>5. Limitation of Liability</h3>
<p>UniDeals shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of our platform.</p>

<h3>6. Changes to Terms</h3>
<p>We reserve the right to modify these terms at any time. Continued use of the platform constitutes acceptance of updated terms.</p>`,
  },
  cookies: {
    title: "Cookie Policy",
    content: `<h2>Cookie Policy</h2>
<p><strong>Last Updated:</strong> April 12, 2026</p>

<h3>1. What Are Cookies</h3>
<p>Cookies are small text files stored on your device when you visit our website. They help us provide a better user experience.</p>

<h3>2. Types of Cookies We Use</h3>
<ul>
<li><strong>Essential Cookies:</strong> Required for basic site functionality</li>
<li><strong>Analytics Cookies:</strong> Help us understand how visitors use our site</li>
<li><strong>Preference Cookies:</strong> Remember your settings and preferences</li>
<li><strong>Marketing Cookies:</strong> Used to deliver relevant advertisements</li>
</ul>

<h3>3. Managing Cookies</h3>
<p>You can control cookies through your browser settings. Note that disabling certain cookies may affect site functionality.</p>

<h3>4. Third-Party Cookies</h3>
<p>Some cookies are placed by third-party services that appear on our pages, such as analytics providers and advertising networks.</p>

<h3>5. Updates to This Policy</h3>
<p>We may update this Cookie Policy periodically. Please review it regularly for any changes.</p>`,
  },
  refund: {
    title: "Refund Policy",
    content: `<h2>Refund Policy</h2>
<p><strong>Last Updated:</strong> April 12, 2026</p>

<h3>1. Free Service</h3>
<p>UniDeals is a free platform for students. We do not charge any fees for accessing scholarship information or coupon codes.</p>

<h3>2. Partner Institution Purchases</h3>
<p>Any purchases made through partner institutions are subject to their respective refund policies. UniDeals is not responsible for refunds on purchases made at partner websites.</p>

<h3>3. Coupon Code Issues</h3>
<p>If a coupon code does not work as expected:</p>
<ul>
<li>Check that the code has not expired</li>
<li>Verify all terms and conditions are met</li>
<li>Contact the partner institution directly</li>
<li>Report the issue to us at support@unideals.in</li>
</ul>

<h3>4. Dispute Resolution</h3>
<p>For any disputes regarding coupon codes or scholarships, please contact our support team. We will work with partner institutions to resolve issues promptly.</p>

<h3>5. Contact Information</h3>
<p>For refund-related queries, email us at support@unideals.in or call +91 98765 43210 (Mon-Fri, 9am-6pm IST).</p>`,
  },
};

// Header Component
export function Header({
  searchQuery,
  setSearchQuery,
  currentPage,
}: {
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
  currentPage?: string;
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 flex-shrink-0">
            <Image src="/logo.svg" alt="UniDeals" width={140} height={40} style={{ height: '36px', width: 'auto' }} />
          </Link>

          {/* Search Bar */}
          {setSearchQuery && (
            <div className="hidden md:flex flex-1 max-w-lg mx-6">
              <div className="relative w-full">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search deals, universities, courses..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-full text-sm focus:ring-2 focus:ring-[#eb4731] focus:border-transparent focus:bg-white transition-all"
                />
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            <Link
              href="/"
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                currentPage === "home" 
                  ? "bg-red-50 text-[#eb4731]" 
                  : "text-[#1A1A1A] hover:bg-gray-50 hover:text-[#eb4731]"
              }`}
            >
              Home
            </Link>
            <Link
              href="/blog"
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                currentPage === "blog" 
                  ? "bg-red-50 text-[#eb4731]" 
                  : "text-[#1A1A1A] hover:bg-gray-50 hover:text-[#eb4731]"
              }`}
            >
              Blog
            </Link>
            <Link
              href="/about"
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                currentPage === "about" 
                  ? "bg-red-50 text-[#eb4731]" 
                  : "text-[#1A1A1A] hover:bg-gray-50 hover:text-[#eb4731]"
              }`}
            >
              About
            </Link>
            <Link
              href="/contact"
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                currentPage === "contact" 
                  ? "bg-red-50 text-[#eb4731]" 
                  : "text-[#1A1A1A] hover:bg-gray-50 hover:text-[#eb4731]"
              }`}
            >
              Contact
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#1A1A1A] hover:text-[#eb4731] transition-colors rounded-lg hover:bg-gray-50"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-100 pt-4">
            {setSearchQuery && (
              <div className="relative mb-4">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search deals..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-full text-sm"
                />
              </div>
            )}
            <div className="flex flex-col gap-1">
              <Link href="/" className="text-gray-600 hover:text-[#eb4731] hover:bg-gray-50 font-medium py-2.5 px-3 rounded-lg transition-all">
                Home
              </Link>
              <Link href="/blog" className="text-gray-600 hover:text-[#eb4731] hover:bg-gray-50 font-medium py-2.5 px-3 rounded-lg transition-all">
                Blog
              </Link>
              <Link href="/about" className="text-gray-600 hover:text-[#eb4731] hover:bg-gray-50 font-medium py-2.5 px-3 rounded-lg transition-all">
                About
              </Link>
              <Link href="/contact" className="text-gray-600 hover:text-[#eb4731] hover:bg-gray-50 font-medium py-2.5 px-3 rounded-lg transition-all">
                Contact
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

// Legal Modal Component
export function LegalModal({
  isOpen,
  onClose,
  content,
}: {
  isOpen: boolean;
  onClose: () => void;
  content: { title: string; content: string };
}) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden animate-in fade-in zoom-in duration-300">
        <div className="bg-[#1A1A1A] px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">{content.title}</h2>
          <button
            onClick={onClose}
            className="text-white/70 hover:text-white transition-colors p-1"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          <div
            className="prose prose-sm max-w-none prose-headings:text-[#1A1A1A] prose-headings:font-semibold prose-p:text-gray-600 prose-li:text-gray-600 prose-strong:text-[#1A1A1A]"
            dangerouslySetInnerHTML={{ __html: content.content }}
          />
        </div>
        <div className="border-t border-gray-200 px-6 py-4 bg-gray-50">
          <button
            onClick={onClose}
            className="w-full bg-[#eb4731] text-white py-3 rounded-xl font-semibold hover:bg-[#d63d2d] transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

// Footer Component with Admin Login and Legal Popups
export function Footer({ onAdminClick }: { onAdminClick?: () => void }) {
  const [legalModal, setLegalModal] = useState<keyof typeof legalContent | null>(null);

  return (
    <>
      <footer className="bg-[#272926] text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-12 mb-12">
            {/* Brand */}
            <div>
              <Link href="/" className="inline-block mb-4">
                <Image 
                  src="/logo-white.svg" 
                  alt="UniDeals" 
                  width={140} 
                  height={40} 
                  style={{ height: '40px', width: 'auto' }}
                />
              </Link>
              <p className="text-gray-400 text-sm leading-relaxed">
                {"India's #1 scholarship and coupon platform for students. Save big on your education journey."}
              </p>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold mb-4 text-white">Company</h4>
              <ul className="space-y-2.5 text-gray-400 text-sm">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-white transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-colors">
                    Contact
                  </Link>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Partner With Us
                  </a>
                </li>
                {onAdminClick && (
                  <li>
                    <button
                      onClick={onAdminClick}
                      className="hover:text-white transition-colors text-left"
                    >
                      Admin Login
                    </button>
                  </li>
                )}
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="font-semibold mb-4 text-white">Legal</h4>
              <ul className="space-y-2.5 text-gray-400 text-sm">
                <li>
                  <button
                    onClick={() => setLegalModal("privacy")}
                    className="hover:text-white transition-colors"
                  >
                    Privacy Policy
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setLegalModal("terms")}
                    className="hover:text-white transition-colors"
                  >
                    Terms of Service
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setLegalModal("cookies")}
                    className="hover:text-white transition-colors"
                  >
                    Cookie Policy
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setLegalModal("refund")}
                    className="hover:text-white transition-colors"
                  >
                    Refund Policy
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; {new Date().getFullYear()} UniDeals. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Legal Modal */}
      {legalModal && (
        <LegalModal
          isOpen={true}
          onClose={() => setLegalModal(null)}
          content={legalContent[legalModal]}
        />
      )}
    </>
  );
}
